library(testthat)
library(simstandard)

test_check("simstandard")
