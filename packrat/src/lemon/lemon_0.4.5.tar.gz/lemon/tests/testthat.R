library(testthat)
library(lemon)


if (TRUE) {
  test_check("lemon")
} #else {
#  test_path <- file.path(getwd(), 'tests', 'testthat')
#  testthat:::test_package_dir('lemon', test_path, filter='test_brackets.R', reporter='summary')
#}